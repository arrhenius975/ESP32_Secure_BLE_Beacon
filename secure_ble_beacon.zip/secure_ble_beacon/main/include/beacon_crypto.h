#ifndef BEACON_CRYPTO_H
#define BEACON_CRYPTO_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

// Encryption key structure
typedef struct {
    uint8_t key[32];  // AES-256 key
    uint8_t iv[16];   // Initialization vector
} beacon_crypto_key_t;

/**
 * @brief Initialize the crypto module
 * @return ESP_OK on success
 */
esp_err_t beacon_crypto_init(void);

/**
 * @brief Generate new encryption keys
 * @param key Pointer to store the generated key
 * @return ESP_OK on success
 */
esp_err_t beacon_crypto_generate_key(beacon_crypto_key_t *key);

/**
 * @brief Encrypt beacon data
 * @param data Input data to encrypt
 * @param len Length of input data
 * @param out_data Output buffer for encrypted data
 * @param out_len Length of output buffer
 * @return ESP_OK on success
 */
esp_err_t beacon_crypto_encrypt(const uint8_t *data, size_t len,
                              uint8_t *out_data, size_t *out_len);

/**
 * @brief Decrypt beacon data
 * @param data Input encrypted data
 * @param len Length of input data
 * @param out_data Output buffer for decrypted data
 * @param out_len Length of output buffer
 * @return ESP_OK on success
 */
esp_err_t beacon_crypto_decrypt(const uint8_t *data, size_t len,
                              uint8_t *out_data, size_t *out_len);

#endif /* BEACON_CRYPTO_H */
