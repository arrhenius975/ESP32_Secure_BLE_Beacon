#ifndef BEACON_CONFIG_H
#define BEACON_CONFIG_H

#include "esp_bt_defs.h"

// Beacon configuration structure
typedef struct {
    uint8_t uuid[16];
    uint16_t major;
    uint16_t minor;
    int8_t power;
    uint16_t adv_int_min;
    uint16_t adv_int_max;
    bool encryption_enabled;
} beacon_config_t;

// Default values
#define DEFAULT_UUID { 0xFD, 0xA5, 0x06, 0x93, 0xA4, 0xE2, 0x4F, 0xB1, \
                      0xAF, 0xCF, 0xC6, 0xEB, 0x07, 0x64, 0x78, 0x25 }
#define DEFAULT_MAJOR 0x0001
#define DEFAULT_MINOR 0x0001
#define DEFAULT_MEASURED_POWER 0xC5

// Advertisement interval limits (units of 0.625ms)
#define MIN_ADV_INTERVAL 0x20  // 20ms
#define MAX_ADV_INTERVAL 0x40  // 40ms

// NVS storage keys
#define NVS_KEY_UUID "uuid"
#define NVS_KEY_MAJOR "major"
#define NVS_KEY_MINOR "minor"
#define NVS_KEY_POWER "power"
#define NVS_KEY_ENC_KEY "enc_key"

// Encryption settings
#define AES_KEY_SIZE 32
#define AES_IV_SIZE 16

#endif /* BEACON_CONFIG_H */
