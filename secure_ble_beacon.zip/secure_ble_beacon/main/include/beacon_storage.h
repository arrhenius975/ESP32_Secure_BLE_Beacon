#ifndef BEACON_STORAGE_H
#define BEACON_STORAGE_H

#include "esp_err.h"
#include "beacon_config.h"
#include "beacon_crypto.h"

/**
 * @brief Initialize NVS storage
 * @return ESP_OK on success
 */
esp_err_t beacon_storage_init(void);

/**
 * @brief Save beacon configuration to NVS
 * @param config Pointer to beacon configuration
 * @return ESP_OK on success
 */
esp_err_t beacon_storage_save_config(const beacon_config_t *config);

/**
 * @brief Load beacon configuration from NVS
 * @param config Pointer to store loaded configuration
 * @return ESP_OK on success
 */
esp_err_t beacon_storage_load_config(beacon_config_t *config);

/**
 * @brief Save encryption key to NVS
 * @param key Pointer to encryption key
 * @return ESP_OK on success
 */
esp_err_t beacon_storage_save_key(const beacon_crypto_key_t *key);

/**
 * @brief Load encryption key from NVS
 * @param key Pointer to store loaded key
 * @return ESP_OK on success
 */
esp_err_t beacon_storage_load_key(beacon_crypto_key_t *key);

#endif /* BEACON_STORAGE_H */
