#include <stdio.h>
#include <string.h>
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_bt.h"
#include "esp_gap_ble_api.h"
#include "esp_bt_main.h"
#include "esp_bt_device.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "beacon_config.h"
#include "beacon_crypto.h"
#include "beacon_storage.h"

static const char *TAG = "SECURE_BLE_BEACON";

static beacon_config_t beacon_config = {
    .uuid = DEFAULT_UUID,
    .major = DEFAULT_MAJOR,
    .minor = DEFAULT_MINOR,
    .power = DEFAULT_MEASURED_POWER,
    .adv_int_min = MIN_ADV_INTERVAL,
    .adv_int_max = MAX_ADV_INTERVAL,
    .encryption_enabled = true
};

static esp_ble_adv_params_t adv_params = {
    .adv_int_min = MIN_ADV_INTERVAL,
    .adv_int_max = MAX_ADV_INTERVAL,
    .adv_type = ADV_TYPE_NONCONN_IND,
    .own_addr_type = BLE_ADDR_TYPE_PUBLIC,
    .channel_map = ADV_CHNL_ALL,
    .adv_filter_policy = ADV_FILTER_ALLOW_SCAN_ANY_CON_ANY,
};

static uint8_t manufacturer_data[25] = {
    0x4C, 0x00,  // Company ID (Apple)
    0x02, 0x15   // iBeacon Type and Length
    // UUID, Major, Minor, and Power will be filled in
};

static void prepare_manufacturer_data(void)
{
    uint8_t *p = &manufacturer_data[4];
    memcpy(p, beacon_config.uuid, 16);
    p += 16;
    
    // Major value
    *p++ = (beacon_config.major >> 8) & 0xFF;
    *p++ = beacon_config.major & 0xFF;
    
    // Minor value
    *p++ = (beacon_config.minor >> 8) & 0xFF;
    *p++ = beacon_config.minor & 0xFF;
    
    // Measured power
    *p = beacon_config.power;

    if (beacon_config.encryption_enabled) {
        uint8_t encrypted_data[25];
        size_t encrypted_len = sizeof(encrypted_data);
        
        esp_err_t ret = beacon_crypto_encrypt(manufacturer_data, sizeof(manufacturer_data),
                                            encrypted_data, &encrypted_len);
        if (ret == ESP_OK) {
            memcpy(manufacturer_data, encrypted_data, encrypted_len);
        } else {
            ESP_LOGE(TAG, "Failed to encrypt manufacturer data");
        }
    }
}

static void esp_gap_cb(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param)
{
    switch (event) {
        case ESP_GAP_BLE_ADV_DATA_RAW_SET_COMPLETE_EVT:
            esp_ble_gap_start_advertising(&adv_params);
            break;
            
        case ESP_GAP_BLE_ADV_START_COMPLETE_EVT:
            if (param->adv_start_cmpl.status == ESP_BT_STATUS_SUCCESS) {
                ESP_LOGI(TAG, "Advertising started successfully");
            } else {
                ESP_LOGE(TAG, "Advertising start failed");
            }
            break;
            
        default:
            break;
    }
}

static void init_bluetooth(void)
{
    ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT));

    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_bt_controller_init(&bt_cfg));
    ESP_ERROR_CHECK(esp_bt_controller_enable(ESP_BT_MODE_BLE));
    ESP_ERROR_CHECK(esp_bluedroid_init());
    ESP_ERROR_CHECK(esp_bluedroid_enable());
    ESP_ERROR_CHECK(esp_ble_gap_register_callback(esp_gap_cb));
}

void app_main(void)
{
    // Initialize NVS
    ESP_LOGI(TAG, "Initializing NVS...");
    ESP_ERROR_CHECK(beacon_storage_init());

    // Initialize crypto
    ESP_LOGI(TAG, "Initializing crypto...");
    ESP_ERROR_CHECK(beacon_crypto_init());

    // Load saved configuration
    ESP_LOGI(TAG, "Loading configuration...");
    esp_err_t ret = beacon_storage_load_config(&beacon_config);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Failed to load config, using defaults");
    }

    // Initialize Bluetooth
    ESP_LOGI(TAG, "Initializing Bluetooth...");
    init_bluetooth();

    // Prepare and set advertising data
    ESP_LOGI(TAG, "Setting up advertising data...");
    prepare_manufacturer_data();
    
    esp_err_t status = esp_ble_gap_config_adv_data_raw(
        (uint8_t*)&manufacturer_data,
        sizeof(manufacturer_data)
    );

    if (status != ESP_OK) {
        ESP_LOGE(TAG, "Failed to configure advertising data");
    }

    ESP_LOGI(TAG, "Beacon initialized successfully");
    ESP_LOGI(TAG, "UUID: %02x%02x%02x%02x-...", 
             beacon_config.uuid[0], beacon_config.uuid[1],
             beacon_config.uuid[2], beacon_config.uuid[3]);
    ESP_LOGI(TAG, "Major: %d, Minor: %d", 
             beacon_config.major, beacon_config.minor);
}
