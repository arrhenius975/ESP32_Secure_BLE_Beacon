#include <string.h>
#include "esp_log.h"
#include "mbedtls/aes.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "beacon_crypto.h"

static const char *TAG = "BEACON_CRYPTO";

static mbedtls_entropy_context entropy;
static mbedtls_ctr_drbg_context ctr_drbg;
static mbedtls_aes_context aes_ctx;
static beacon_crypto_key_t current_key;

esp_err_t beacon_crypto_init(void)
{
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_aes_init(&aes_ctx);

    int ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy,
                                   NULL, 0);
    if (ret != 0) {
        ESP_LOGE(TAG, "Failed to seed RNG: -0x%04x", -ret);
        return ESP_FAIL;
    }

    return ESP_OK;
}

esp_err_t beacon_crypto_generate_key(beacon_crypto_key_t *key)
{
    if (key == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    int ret = mbedtls_ctr_drbg_random(&ctr_drbg, key->key, sizeof(key->key));
    if (ret != 0) {
        ESP_LOGE(TAG, "Failed to generate key: -0x%04x", -ret);
        return ESP_FAIL;
    }

    ret = mbedtls_ctr_drbg_random(&ctr_drbg, key->iv, sizeof(key->iv));
    if (ret != 0) {
        ESP_LOGE(TAG, "Failed to generate IV: -0x%04x", -ret);
        return ESP_FAIL;
    }

    memcpy(&current_key, key, sizeof(beacon_crypto_key_t));
    return ESP_OK;
}

esp_err_t beacon_crypto_encrypt(const uint8_t *data, size_t len,
                              uint8_t *out_data, size_t *out_len)
{
    if (data == NULL || out_data == NULL || out_len == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (*out_len < len) {
        return ESP_ERR_INVALID_SIZE;
    }

    size_t nc_off = 0;
    unsigned char stream_block[16] = {0};

    mbedtls_aes_setkey_enc(&aes_ctx, current_key.key, 256);
    
    int ret = mbedtls_aes_crypt_ctr(&aes_ctx, len, &nc_off,
                                   current_key.iv, stream_block,
                                   data, out_data);
    
    if (ret != 0) {
        ESP_LOGE(TAG, "Encryption failed: -0x%04x", -ret);
        return ESP_FAIL;
    }

    *out_len = len;
    return ESP_OK;
}

esp_err_t beacon_crypto_decrypt(const uint8_t *data, size_t len,
                              uint8_t *out_data, size_t *out_len)
{
    // In CTR mode, encryption and decryption are the same operation
    return beacon_crypto_encrypt(data, len, out_data, out_len);
}
