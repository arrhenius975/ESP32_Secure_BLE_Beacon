#include <string.h>
#include "esp_log.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "beacon_storage.h"

static const char *TAG = "BEACON_STORAGE";
static const char *STORAGE_NAMESPACE = "beacon";

static nvs_handle_t storage_handle;

esp_err_t beacon_storage_init(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        // NVS partition was truncated and needs to be erased
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    ret = nvs_open(STORAGE_NAMESPACE, NVS_READWRITE, &storage_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error opening NVS handle: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}

esp_err_t beacon_storage_save_config(const beacon_config_t *config)
{
    if (config == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t ret;

    // Save UUID
    ret = nvs_set_blob(storage_handle, NVS_KEY_UUID, config->uuid, sizeof(config->uuid));
    if (ret != ESP_OK) return ret;

    // Save Major
    ret = nvs_set_u16(storage_handle, NVS_KEY_MAJOR, config->major);
    if (ret != ESP_OK) return ret;

    // Save Minor
    ret = nvs_set_u16(storage_handle, NVS_KEY_MINOR, config->minor);
    if (ret != ESP_OK) return ret;

    // Save Power
    ret = nvs_set_i8(storage_handle, NVS_KEY_POWER, config->power);
    if (ret != ESP_OK) return ret;

    // Commit changes
    ret = nvs_commit(storage_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error committing to NVS: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}

esp_err_t beacon_storage_load_config(beacon_config_t *config)
{
    if (config == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t ret;
    size_t required_size;

    // Load UUID
    required_size = sizeof(config->uuid);
    ret = nvs_get_blob(storage_handle, NVS_KEY_UUID, config->uuid, &required_size);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) return ret;

    // Load Major
    ret = nvs_get_u16(storage_handle, NVS_KEY_MAJOR, &config->major);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) return ret;

    // Load Minor
    ret = nvs_get_u16(storage_handle, NVS_KEY_MINOR, &config->minor);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) return ret;

    // Load Power
    ret = nvs_get_i8(storage_handle, NVS_KEY_POWER, &config->power);
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) return ret;

    return ESP_OK;
}

esp_err_t beacon_storage_save_key(const beacon_crypto_key_t *key)
{
    if (key == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t ret = nvs_set_blob(storage_handle, NVS_KEY_ENC_KEY, key, sizeof(beacon_crypto_key_t));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error saving encryption key: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = nvs_commit(storage_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error committing encryption key: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}

esp_err_t beacon_storage_load_key(beacon_crypto_key_t *key)
{
    if (key == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    size_t required_size = sizeof(beacon_crypto_key_t);
    esp_err_t ret = nvs_get_blob(storage_handle, NVS_KEY_ENC_KEY, key, &required_size);
    
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NOT_FOUND) {
        ESP_LOGE(TAG, "Error loading encryption key: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}
